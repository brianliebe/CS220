Contained are some files:
 - Converter.exe - use this to try practice problems or to convert between systems.
 - Lesson.exe - a simple explanation of number systems.
 
Other included files (in 'Source' folder):
 - Converter.py - don't use unless you have Python installed.
 - Converter.txt - source code used for the program.
 - Lesson.py - don't use unless you have Python installed.
 - Lesson.txt - source code used for the lesson.

 
Just run the file "Converter.exe" or "Lesson.exe" since the .py versions can only run with Python 2.7 installed.

If you run "Converter.exe":

	After the file opens, follow the directions to either choose to convert between bases or to try practice problems.

	If you choose practice problems, try to get through as many as possible without 'cheating.'

	If you think you know the answer, input it and it'll tell you if you're right.
	
If you run "Lesson.exe":

	Scroll through the pages using 'Enter.' 

I included a limited number (30) of practice problems using the file 'practice.txt'.
To add you own practice problems, open '\Digital Midterm Project\Converter\dist\Converter\practice.txt' and follow these steps:
 
 1) Select two bases - 1 to convert from, and one to convert to. Don't go over 36.
 2) Select a number you want to convert (make sure it makes sense in that base, or else it won't work).
 3) Get the answer (you can use Converter.exe to check the answer).
 4) Open 'practice.txt' and add new lines of text at the bottom. Follow the correct format:
    ----------#
	<Start Base>
	<Finish Base>
	<Start Number>
	<Correct Answer>


