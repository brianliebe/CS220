import sys
import os
from random import randint

def remove_spaces(lst):
    return ''.join([str(item) for item in lst])

def IsInt(s):
    try: 
        int(s)
        return True
    except ValueError:
        return False

def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)

def cls():
    os.system(['clear','cls'][os.name == 'nt'])
    
def displayTitle():
    print"        ========================================================="
    print"        =                                                       ="
    print"        =         Brian Liebe's Number-System Converter         ="
    print"        =                                                       ="
    print"        =    Convert Between Any Number System From Base 2-36   ="
    print"        =                                                       ="
    print"        =========================================================\n"

ProgramIsFinished = False
fileName = 'DoNotChange\DoNotChange.txt'
num_lines = sum(1 for line in open(fileName) if line != '\n')
nfile = open(fileName)
lines = nfile.readlines()

checkEnter1 = 0
checkEnter2 = 0
checkEnter3 = 0

while ProgramIsFinished == False:
    cls()
    displayTitle()

    inputType = raw_input("Enter 'convert' for converting or 'practice' for practice problems. \n> ")
    inputType = inputType.replace(" ", "")
    if inputType.strip() in "practice Practice PRACTICE prac p P Prac PRAC prob Prob PROB pp PP pr Pr PR pract Pract PRACT practiceproblems".split():
        practiceLoop = False
        cls()
        displayTitle()
        while practiceLoop == False:
            practiceProblemChoice = randint(1,(num_lines / 5 - 1))
            base1 = lines[(practiceProblemChoice * 5) + 1].rstrip('\n')
            base2 = lines[(practiceProblemChoice * 5) + 2].rstrip('\n')
            startNumber = lines[(practiceProblemChoice * 5) + 3].rstrip('\n')
            problemAnswer = lines[(practiceProblemChoice * 5) + 4].rstrip('\n')
            print "Random Practice Problem: Convert '" + startNumber + "' from Base", base1, "to Base", base2 + ".\n"
            problemUserAnswer = raw_input("Your answer: ")
            if problemUserAnswer == problemAnswer:
                print "\nCorrect! "
            elif problemUserAnswer == "":
                print "\nYou didn't answer! Therefore you're incorrect! The correct answer was", problemAnswer + "."
            else:
                print "\nThat's incorrect! The correct answer was", problemAnswer + "."
            anotherProblem = raw_input("\nWould you like another practice problem? \n> ")
            if anotherProblem.strip() in "n N no No NO".split():
                sys.exit()
            cls()
            displayTitle()
    keepConverting = True
    while keepConverting == True:
        cls()
        displayTitle()
        list = []
        del list
        checkEnter1 = 0
        checkEnter2 = 0
        checkEnter3 = 0
        while checkEnter1 == 0:
            StartBase = raw_input("Base you are converting from: \n> ")
            if StartBase.isdigit() == False:
                print "Please enter a valid base.\n"
            else:
                StartBase = int(StartBase)
                checkEnter1 = 1
        while checkEnter2 == 0:
            EndBase = raw_input("\nBase you are converting to: \n> ")
            if EndBase.isdigit() == False:
                print "Please enter a valid base."
            else:
                EndBase = int(EndBase)
                checkEnter2 = 1
        while checkEnter3 == 0:
            InitialNumber = raw_input("\nNumber you are starting with: \n> ")
            if InitialNumber == "" or InitialNumber == "\n":
                print "Please enter a valid number."
            else:
                InitialNumber = InitialNumber.upper()
                checkEnter3 = 1

        Sum = 0
        Power = -1
        list = list(InitialNumber)[::-1]

        while len(list) > 0:
            Power = Power + 1
            if IsInt(list[0]) == True:
                Sum = (Sum + (int(list[0]) * (StartBase ** Power)))
            elif IsInt(list[0]) == False:
                if list[0] == "A":
                    Sum = (Sum + (10 * (StartBase ** Power)))
                elif list[0] == "B":
                    Sum = (Sum + (11 * (StartBase ** Power)))
                elif list[0] == "C":
                    Sum = (Sum + (12 * (StartBase ** Power)))
                elif list[0] == "D":
                    Sum = (Sum + (13 * (StartBase ** Power)))
                elif list[0] == "E":
                    Sum = (Sum + (14 * (StartBase ** Power)))
                elif list[0] == "F":
                    Sum = (Sum + (15 * (StartBase ** Power)))
                elif list[0] == "G":
                    Sum = (Sum + (16 * (StartBase ** Power)))
                elif list[0] == "H":
                    Sum = (Sum + (17 * (StartBase ** Power)))
                elif list[0] == "I":
                    Sum = (Sum + (18 * (StartBase ** Power)))
                elif list[0] == "J":
                    Sum = (Sum + (19 * (StartBase ** Power)))
                elif list[0] == "K":
                    Sum = (Sum + (20 * (StartBase ** Power)))
                elif list[0] == "L":
                    Sum = (Sum + (21 * (StartBase ** Power)))
                elif list[0] == "M":
                    Sum = (Sum + (22 * (StartBase ** Power)))
                elif list[0] == "N":
                    Sum = (Sum + (23 * (StartBase ** Power)))
                elif list[0] == "O":
                    Sum = (Sum + (24 * (StartBase ** Power)))
                elif list[0] == "P":
                    Sum = (Sum + (25 * (StartBase ** Power)))
                elif list[0] == "Q":
                    Sum = (Sum + (26 * (StartBase ** Power)))
                elif list[0] == "R":
                    Sum = (Sum + (27 * (StartBase ** Power)))
                elif list[0] == "S":
                    Sum = (Sum + (28 * (StartBase ** Power)))
                elif list[0] == "T":
                    Sum = (Sum + (29 * (StartBase ** Power)))
                elif list[0] == "U":
                    Sum = (Sum + (30 * (StartBase ** Power)))
                elif list[0] == "V":
                    Sum = (Sum + (31 * (StartBase ** Power)))
                elif list[0] == "W":
                    Sum = (Sum + (32 * (StartBase ** Power)))
                elif list[0] == "X":
                    Sum = (Sum + (33 * (StartBase ** Power)))
                elif list[0] == "Y":
                    Sum = (Sum + (34 * (StartBase ** Power)))
                elif list[0] == "Z":
                    Sum = (Sum + (35 * (StartBase ** Power)))
                
            del list[0]

        
        while Sum > 0:
            d = Sum % EndBase
            list.append(d)
            Sum = (Sum - d) / EndBase

        for n,i in enumerate(list):
            if i == 10:
                list[n] = "A"
            elif i == 11:
                list[n] = "B"
            elif i == 12:
                list[n] = "C"
            elif i == 13:
                list[n] = "D"
            elif i == 14:
                list[n] = "E"
            elif i == 15:
                list[n] = "F"
            elif i == 16:
                list[n] = "G"
            elif i == 17:
                list[n] = "H"
            elif i == 18:
                list[n] = "I"
            elif i == 19:
                list[n] = "J"
            elif i == 20:
                list[n] = "K"
            elif i == 21:
                list[n] = "L"
            elif i == 22:
                list[n] = "M"
            elif i == 23:
                list[n] = "N"
            elif i == 24:
                list[n] = "O"
            elif i == 25:
                list[n] = "P"
            elif i == 26:
                list[n] = "Q"
            elif i == 27:
                list[n] = "R"
            elif i == 28:
                list[n] = "S"
            elif i == 29:
                list[n] = "T"
            elif i == 30:
                list[n] = "U"
            elif i == 31:
                list[n] = "V"
            elif i == 32:
                list[n] = "W"
            elif i == 33:
                list[n] = "X"
            elif i == 34:
                list[n] = "Y"
            elif i == 35:
                list[n] = "Z"

        finalOutput = remove_spaces(list[::-1])

        print "\n\nThe number '" + InitialNumber + "' from Base", StartBase, "to Base", EndBase, "is:", finalOutput

        RestartProgram = raw_input("\n\nDo you want to restart this program? ")
        if RestartProgram.strip() in "n N no No NO".split():
            ProgramIsFinished = True
            keepConverting = False
        else:
            cls()
            