import os
import sys

def cls():
    os.system(['clear','cls'][os.name == 'nt'])

def PrintFile(fname):
    with open(fname, 'r') as fin:
        print fin.read()
        nextpage = raw_input("")
        cls()

def RunEverything():
    PrintFile("DoNotChange\start.txt")
    PrintFile("DoNotChange\page1.txt")
    PrintFile("DoNotChange\page2.txt")
    PrintFile("DoNotChange\page3.txt")
    PrintFile("DoNotChange\page4.txt")
    PrintFile("DoNotChange\page5.txt")
    PrintFile("DoNotChange\page6.txt")
    
RunEverything()
done = raw_input("")
