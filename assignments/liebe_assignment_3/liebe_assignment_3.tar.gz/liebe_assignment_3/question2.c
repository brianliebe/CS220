/*
 * Complete the function below.
 */
void swap_temp(int *num1, int *num2) {
    int temp = *num1;
    //printf("%d %d \n", *num1, *num2);
    *num1 = *num2;
    *num2 = temp;
    //printf("%d %d \n", num1, num2);
    
    

}

