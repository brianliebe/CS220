Brian Liebe

'make' will compile it or use 'gcc poker.c -o poker -std=c89'

run it with './poker sample_hands.txt' aka './poker <FILE_NAME>' and it'll always output to Output.txt